class Book(object):
    """ class for a single Book object """

    def __init__(self):
        """ constructor for book object, given ____________________ """
        ###  DATA FIELDS TO BE COMPLETED BY YOU  ###
        pass

    def __str__(self):
        """ pretty-print info about this object """
        ###  TO BE COMPLETED BY YOU  ###
        pass

    ###  METHODS TO BE COMPLETED BY YOU  ###



if __name__ == '__main__':

    print("Testing the Book class...")
    myBook = Book("Gettysburg Address", "Abe Lincoln", 1863,
    "book-database/gettysburg.txt")

    print("Testing toString...")
    print(myBook.toString())

    print("Testing getFilename...")
    print(myBook.getFilename())

    print("Testing getText...")
    text = myBook.getText()
    print(text[:105])                   # only print the first couple of lines

    print("bookmark is:", myBook.getBookmark())
    myBook.setBookmark(12)
    print("now bookmark is:", myBook.getBookmark())

    ################ Write additional tests below ###################
